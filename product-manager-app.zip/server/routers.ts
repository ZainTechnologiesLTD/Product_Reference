import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  createProduct,
  getUserProducts,
  getProductById,
  updateProduct,
  deleteProduct,
  checkProductNameExists,
} from "./db";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  products: router({
    list: protectedProcedure.query(({ ctx }) => getUserProducts(ctx.user.id)),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1, "Product name is required").max(255),
          category: z.string().min(1, "Category is required").max(100),
          description: z.string().optional(),
          reference: z.string().min(1).max(50),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Check for duplicate product name
        const exists = await checkProductNameExists(ctx.user.id, input.name);
        if (exists) {
          throw new TRPCError({
            code: "CONFLICT",
            message: `Product with name "${input.name}" already exists`,
          });
        }

        const product = await createProduct({
          userId: ctx.user.id,
          name: input.name,
          category: input.category,
          description: input.description,
          reference: input.reference,
        });

        if (!product) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to create product",
          });
        }

        return product;
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ ctx, input }) => getProductById(input.id, ctx.user.id)),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().min(1).max(255).optional(),
          category: z.string().min(1).max(100).optional(),
          description: z.string().optional(),
          reference: z.string().min(1).max(50).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...updates } = input;

        // Verify product exists and belongs to user
        const existing = await getProductById(id, ctx.user.id);
        if (!existing) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Product not found",
          });
        }

        // Check for duplicate name if name is being updated
        if (updates.name && updates.name !== existing.name) {
          const exists = await checkProductNameExists(ctx.user.id, updates.name, id);
          if (exists) {
            throw new TRPCError({
              code: "CONFLICT",
              message: `Product with name "${updates.name}" already exists`,
            });
          }
        }

        const updated = await updateProduct(id, ctx.user.id, updates);
        if (!updated) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to update product",
          });
        }

        return updated;
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        // Verify product exists and belongs to user
        const existing = await getProductById(input.id, ctx.user.id);
        if (!existing) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Product not found",
          });
        }

        const success = await deleteProduct(input.id, ctx.user.id);
        if (!success) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to delete product",
          });
        }

        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
