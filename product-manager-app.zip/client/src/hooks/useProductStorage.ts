import { useState, useEffect, useCallback } from 'react';

interface Product {
  id: number;
  name: string;
  category: string;
  reference: string;
}

interface UseProductStorageReturn {
  products: Product[];
  addProduct: (product: Omit<Product, 'id'>) => boolean;
  deleteProduct: (id: number) => void;
  updateProducts: (products: Product[]) => void;
  isStorageAvailable: boolean;
  exportToExcel: (products: Product[]) => void;
}

const DEFAULT_PRODUCTS: Product[] = [
  { id: 1, name: 'Tubo', category: 'Cali', reference: 'CA593' },
  { id: 2, name: 'Light', category: 'Elec', reference: 'EL214' }
];

export function useProductStorage(): UseProductStorageReturn {
  const [products, setProducts] = useState<Product[]>([]);
  const [isStorageAvailable, setIsStorageAvailable] = useState(true);

  // Initialize products from localStorage
  useEffect(() => {
    try {
      const testKey = '__storage_test__';
      localStorage.setItem(testKey, 'test');
      localStorage.removeItem(testKey);
      setIsStorageAvailable(true);

      const saved = localStorage.getItem('products');
      setProducts(saved ? JSON.parse(saved) : DEFAULT_PRODUCTS);
    } catch (e) {
      console.error('Storage error:', e);
      setIsStorageAvailable(false);
      setProducts(DEFAULT_PRODUCTS);
    }
  }, []);

  // Persist products to localStorage
  useEffect(() => {
    if (!isStorageAvailable) return;

    try {
      localStorage.setItem('products', JSON.stringify(products));
    } catch (e) {
      console.error('Failed to save products:', e);
      setIsStorageAvailable(false);
    }
  }, [products, isStorageAvailable]);

  const addProduct = useCallback((product: Omit<Product, 'id'>) => {
    setProducts(prev => {
      // Check for duplicates
      const isDuplicate = prev.some(p => p.name.toLowerCase() === product.name.toLowerCase());
      if (isDuplicate) return prev;

      return [
        ...prev,
        {
          ...product,
          id: Date.now()
        }
      ];
    });
    return true;
  }, []);

  const deleteProduct = useCallback((id: number) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  }, []);

  const updateProducts = useCallback((newProducts: Product[]) => {
    setProducts(newProducts);
  }, []);

  const exportToExcel = useCallback((productsToExport: Product[]) => {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, '-');

    const htmlTable = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
      <head><meta charset="UTF-8"></head>
      <body>
        <table border="1">
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Category</th>
              <th>Reference</th>
            </tr>
          </thead>
          <tbody>
            ${productsToExport.map(p => `
              <tr>
                <td>${p.name}</td>
                <td>${p.category}</td>
                <td>${p.reference}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </body>
      </html>
    `;

    const blob = new Blob([htmlTable], { type: 'application/vnd.ms-excel' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `products_backup_${dateStr}_${timeStr}.xls`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }, []);

  return {
    products,
    addProduct,
    deleteProduct,
    updateProducts,
    isStorageAvailable,
    exportToExcel
  };
}
