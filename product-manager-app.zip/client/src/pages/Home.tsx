import ProductTable from '@/components/ProductTable';
import { useAuth } from '@/_core/hooks/useAuth';
import { getLoginUrl } from '@/const';

/**
 * Home Page - Product Reference Manager
 * 
 * Design Philosophy: Modern Enterprise Dashboard
 * - Clean, data-driven aesthetic inspired by modern SaaS platforms
 * - Professional restraint with strategic accent colors
 * - Emphasis on clarity and efficiency
 */
export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  // Show login prompt if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Product Reference Manager</h1>
          <p className="text-slate-600 mb-8">Please log in to manage your products</p>
          <a
            href={getLoginUrl()}
            className="inline-block bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  // Show product manager when authenticated
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <ProductTable />
    </div>
  );
}
