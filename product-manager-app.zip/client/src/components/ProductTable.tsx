import React, { useState, useMemo } from 'react';
import { Plus, Trash2, Search, Download, Upload, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';

interface NewProduct {
  name: string;
  category: string;
}

export default function ProductTable() {
  // tRPC Queries and Mutations
  const utils = trpc.useUtils();
  const { data: products = [], isLoading, error } = trpc.products.list.useQuery();
  const createMutation = trpc.products.create.useMutation();
  const deleteMutation = trpc.products.delete.useMutation();

  // Local State
  const [newProduct, setNewProduct] = useState<NewProduct>({ name: '', category: '' });
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestions, setSuggestions] = useState<typeof products>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [categorySuggestions, setCategorySuggestions] = useState<string[]>([]);
  const [showCategorySuggestions, setShowCategorySuggestions] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);

  // Utility Functions
  function generateReference(category: string): string {
    const prefix = category.substring(0, 2).toUpperCase();
    const numbers = Math.floor(Math.random() * 900) + 100;
    return `${prefix}${numbers}`;
  }

  // Event Handlers
  const handleProductNameChange = (value: string) => {
    setNewProduct({ ...newProduct, name: value });

    if (value.trim().length > 0) {
      const matches = products.filter(p =>
        p.name.toLowerCase().includes(value.toLowerCase())
      );
      setSuggestions(matches);
      setShowSuggestions(matches.length > 0);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const selectSuggestion = (product: typeof products[0]) => {
    setNewProduct({ name: product.name, category: product.category });
    setShowSuggestions(false);
    setSuggestions([]);
  };

  const handleCategoryChange = (value: string) => {
    setNewProduct({ ...newProduct, category: value });

    if (value.trim().length > 0) {
      const uniqueCategories = Array.from(new Set(products.map(p => p.category)));
      const matches = uniqueCategories.filter(cat =>
        cat.toLowerCase().includes(value.toLowerCase())
      );
      setCategorySuggestions(matches);
      setShowCategorySuggestions(matches.length > 0);
    } else {
      setCategorySuggestions([]);
      setShowCategorySuggestions(false);
    }
  };

  const selectCategory = (category: string) => {
    setNewProduct({ ...newProduct, category });
    setShowCategorySuggestions(false);
    setCategorySuggestions([]);
  };

  const addProduct = async () => {
    if (!newProduct.name.trim() || !newProduct.category.trim()) {
      toast.error('Please fill in both product name and category.');
      return;
    }

    try {
      await createMutation.mutateAsync({
        name: newProduct.name.trim(),
        category: newProduct.category.trim(),
        reference: generateReference(newProduct.category.trim()),
      });

      setNewProduct({ name: '', category: '' });
      await utils.products.list.invalidate();
      toast.success('Product added successfully!');
    } catch (error: any) {
      toast.error(error.message || 'Failed to add product');
    }
  };

  const deleteProduct = async (id: number) => {
    try {
      await deleteMutation.mutateAsync({ id });
      await utils.products.list.invalidate();
      toast.success('Product deleted successfully!');
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete product');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      addProduct();
    }
  };

  const downloadBackup = () => {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, '-');

    const htmlTable = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
      <head><meta charset="UTF-8"></head>
      <body>
        <table border="1">
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Category</th>
              <th>Reference</th>
            </tr>
          </thead>
          <tbody>
            ${products.map(p => `
              <tr>
                <td>${p.name}</td>
                <td>${p.category}</td>
                <td>${p.reference}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </body>
      </html>
    `;

    const blob = new Blob([htmlTable], { type: 'application/vnd.ms-excel' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `products_backup_${dateStr}_${timeStr}.xls`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    toast.success('Backup downloaded successfully!');
  };

  const importFromExcel = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const content = e.target?.result as string;
        const parser = new DOMParser();
        const doc = parser.parseFromString(content, 'text/html');
        const rows = doc.querySelectorAll('table tr');

        let importedCount = 0;

        for (let i = 1; i < rows.length; i++) {
          const cells = rows[i].querySelectorAll('td');
          if (cells.length >= 3) {
            const name = cells[0].textContent?.trim() || '';
            const category = cells[1].textContent?.trim() || '';
            const reference = cells[2].textContent?.trim() || '';

            if (name && category && reference) {
              try {
                await createMutation.mutateAsync({
                  name,
                  category,
                  reference,
                });
                importedCount++;
              } catch (error) {
                // Skip duplicates
                console.warn(`Skipped duplicate: ${name}`);
              }
            }
          }
        }

        if (importedCount > 0) {
          await utils.products.list.invalidate();
          toast.success(`Successfully imported ${importedCount} products!`);
          setShowImportDialog(false);
        } else {
          toast.error('No valid products found in the file.');
        }
      } catch (error) {
        console.error('Import error:', error);
        toast.error('Failed to import file. Please use a valid Excel backup file.');
      }
    };

    reader.readAsText(file);
    event.target.value = '';
  };

  // Filtered Products
  const filteredProducts = useMemo(() => {
    if (!searchTerm.trim()) return products;

    const term = searchTerm.toLowerCase();
    return products.filter(p =>
      p.name.toLowerCase().includes(term) ||
      p.category.toLowerCase().includes(term) ||
      p.reference.toLowerCase().includes(term)
    );
  }, [products, searchTerm]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-6 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading products...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Product Reference Manager</h1>
          <p className="text-slate-600">Manage and track your product inventory with ease</p>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-red-900">Error Loading Products</p>
              <p className="text-sm text-red-700">Failed to load products from the database.</p>
            </div>
          </div>
        )}

        {/* Main Content Card */}
        <Card className="card-elevated">
          {/* Top Controls */}
          <div className="p-6 border-b border-slate-200">
            <div className="flex flex-col gap-4">
              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  type="text"
                  placeholder="Search by product name, category, or reference..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 input-field"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-3">
                <Button
                  onClick={downloadBackup}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  Export to Excel
                </Button>

                <Button
                  onClick={() => setShowImportDialog(true)}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <Upload className="w-4 h-4" />
                  Import from Excel
                </Button>
              </div>
            </div>
          </div>

          {/* Add Product Section */}
          <div className="p-6 border-b border-slate-200 bg-slate-50">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">Add New Product</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Product Name Input */}
              <div className="relative">
                <label className="block text-sm font-medium text-slate-700 mb-2">Product Name</label>
                <Input
                  type="text"
                  placeholder="Enter product name"
                  value={newProduct.name}
                  onChange={(e) => handleProductNameChange(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="input-field"
                />
                {showSuggestions && suggestions.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-lg z-10">
                    {suggestions.map((product) => (
                      <button
                        key={product.id}
                        onClick={() => selectSuggestion(product)}
                        className="w-full text-left px-4 py-2 hover:bg-slate-50 text-sm text-slate-700 border-b border-slate-100 last:border-b-0"
                      >
                        {product.name} ({product.category})
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Category Input */}
              <div className="relative">
                <label className="block text-sm font-medium text-slate-700 mb-2">Category</label>
                <Input
                  type="text"
                  placeholder="Enter category"
                  value={newProduct.category}
                  onChange={(e) => handleCategoryChange(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="input-field"
                />
                {showCategorySuggestions && categorySuggestions.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-slate-200 rounded-lg shadow-lg z-10">
                    {categorySuggestions.map((category) => (
                      <button
                        key={category}
                        onClick={() => selectCategory(category)}
                        className="w-full text-left px-4 py-2 hover:bg-slate-50 text-sm text-slate-700 border-b border-slate-100 last:border-b-0"
                      >
                        {category}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Add Button */}
              <div className="flex items-end">
                <Button
                  onClick={addProduct}
                  disabled={createMutation.isPending}
                  className="w-full button-primary flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  {createMutation.isPending ? 'Adding...' : 'Add Product'}
                </Button>
              </div>
            </div>
          </div>

          {/* Products Table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50">
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Product Name</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Category</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">Reference</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-slate-900">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.length > 0 ? (
                  filteredProducts.map((product) => (
                    <tr key={product.id} className="border-b border-slate-200 hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 text-sm text-slate-900 font-medium">{product.name}</td>
                      <td className="px-6 py-4 text-sm text-slate-600">{product.category}</td>
                      <td className="px-6 py-4 text-sm text-slate-600 font-mono">{product.reference}</td>
                      <td className="px-6 py-4 text-center">
                        <Button
                          onClick={() => deleteProduct(product.id)}
                          disabled={deleteMutation.isPending}
                          variant="ghost"
                          size="sm"
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="px-6 py-12 text-center text-slate-500">
                      <p className="text-sm">No products found. Add your first product to get started.</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Footer Stats */}
          <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex justify-between text-sm text-slate-600">
            <span>Total Products: <strong className="text-slate-900">{products.length}</strong></span>
            <span>Showing: <strong className="text-slate-900">{filteredProducts.length}</strong></span>
          </div>
        </Card>
      </div>

      {/* Import Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Import Products from Excel</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-slate-600">
              Select an Excel backup file to import products. The file must contain columns for Product Name, Category, and Reference.
            </p>
            <input
              type="file"
              accept=".xls,.xlsx,.csv"
              onChange={importFromExcel}
              className="block w-full text-sm text-slate-500
                file:mr-4 file:py-2 file:px-4
                file:rounded-md file:border-0
                file:text-sm file:font-semibold
                file:bg-indigo-50 file:text-indigo-700
                hover:file:bg-indigo-100"
            />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
