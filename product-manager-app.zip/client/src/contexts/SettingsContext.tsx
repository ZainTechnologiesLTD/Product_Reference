import React, { createContext, useContext, useState, useEffect } from 'react';

interface SettingsContextType {
  autoBackup: boolean;
  setAutoBackup: (value: boolean) => void;
  theme: 'light' | 'dark';
  setTheme: (value: 'light' | 'dark') => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [autoBackup, setAutoBackupState] = useState(() => {
    try {
      const saved = localStorage.getItem('autoBackup');
      return saved ? JSON.parse(saved) : true;
    } catch {
      return true;
    }
  });

  const [theme, setThemeState] = useState<'light' | 'dark'>(() => {
    try {
      const saved = localStorage.getItem('theme');
      return (saved as 'light' | 'dark') || 'light';
    } catch {
      return 'light';
    }
  });

  // Persist autoBackup setting
  useEffect(() => {
    try {
      localStorage.setItem('autoBackup', JSON.stringify(autoBackup));
    } catch (e) {
      console.error('Failed to save autoBackup setting:', e);
    }
  }, [autoBackup]);

  // Persist theme setting
  useEffect(() => {
    try {
      localStorage.setItem('theme', theme);
      // Apply theme to document
      if (theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    } catch (e) {
      console.error('Failed to save theme setting:', e);
    }
  }, [theme]);

  const setAutoBackup = (value: boolean) => {
    setAutoBackupState(value);
  };

  const setTheme = (value: 'light' | 'dark') => {
    setThemeState(value);
  };

  return (
    <SettingsContext.Provider value={{ autoBackup, setAutoBackup, theme, setTheme }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}
